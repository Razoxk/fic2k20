<h4 class="ctitulo2 rounded-lg">2 - Antecedentes de la Iniciativa</h4>
            <h4>2.1 Prioridad Regional que Abordará la Iniciativa</h4>
            <h6 class="alert alert-secondary col-md-4">Sólo se podrá marcar una casilla. <br>Indicar la que tenga mayor
              relevancia con la iniciativa propuesta.</h6>
            
            <div class="row container">
              <div  align="center" class="col-md-3 border border-dark" style="background: #E2E3E5;" ><b>PROGRAMAS</b></div>
              <div class="col-md-1 border border-dark" style="background: #E2E3E5;"></div>
              <div align="center" class="col-md-4 border border-dark" style="background: #E2E3E5;"><b>PROYECTOS Y/O ACCIONES</b></div>
            </div> 

            <!-- 2.1 -->

            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Tecnificación del riego pequeños productores utilizando ERNC. </div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input type="radio" value="Tecnificación del riego pequeños productores utilizando ERNC" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >  I+D+i para nuevos revestimientos para canales de distribución de agua.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input type="radio" value="I+D+i para nuevos revestimientos para canales de distribución de agua" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >  Agricultura de precisión para certificado orgánico.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Agricultura de precisión para certificado orgánico." type="radio" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >  I+D+i para apoyo al reciclaje y la valorización de los de desechos y subproductos de las actividades productivas regionales: minería, agropecuario, construcción y turismo.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="I+D+i para apoyo al reciclaje y la valorización de los de desechos y subproductos de las actividades productivas regionales: minería, agropecuario, construcción y turismo." type="radio" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" >1.1 La Promoción de la Economia Circular</div>
            <div class="col-md-1 border-left border-dark" style="background: #E2E3E5;"><input value="La Promoción de la Economia Circular" type="radio" name="options1" id="options1"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >I+D+i para la: gestión y manejo de los recursos hídricos; mejora de la calidad del agua; optimización y reutilización del agua de riego y su tecnificación.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="I+D+i para la: gestión y manejo de los recursos hídricos; mejora de la calidad del agua; optimización y reutilización del agua de riego y su tecnificación." type="radio" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >    La promoción y el apoyo para la utilización de ERNC y mejora de la eficiencia energética de los procesos productivos y en la prestación de servicios (turismo).</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input type="radio" value="La promoción y el apoyo para la utilización de ERNC y mejora de la eficiencia energética de los procesos productivos y en la prestación de servicios (turismo)." name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >      I+D+i para favorecer la seguridad, trazabilidad e inocuidad alimentaria relacionadas con el uso del agua o la valorización de subproductos agrícolas.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input type="radio" value="I+D+i para favorecer la seguridad, trazabilidad e inocuidad alimentaria relacionadas con el uso del agua o la valorización de subproductos agrícolas." name="options1" id="option1"></div>
            </div>

            <!-- 1.1 -->

            <!-- 1.2 -->
            <div class="row container">
            <div  class="col-md-3 border-left border-top border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-top border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Desarrollo de nuevas variedades mejoradas y adaptadas tanto a los efectos del cambio climático, como a los requerimientos del mercado.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Desarrollo de nuevas variedades mejoradas y adaptadas tanto a los efectos del cambio climático, como a los requerimientos del mercado." type="radio" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" >1.2 Diversificación y adaptación de los cultivos al cambio climático</div>
            <div class="col-md-1 border-left border-dark" style="background: #E2E3E5;"><input value="Diversificación y adaptación de los cultivos al cambio climático" type="radio" name="options1" id="options1"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Introducción de nuevos cultivos y nuevas variedades (especies) adaptados a las nuevas condiciones climatológicas e instrumentar programas de cultivos adaptados a las condiciones locales (secano, regadío)</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Introducción de nuevos cultivos y nuevas variedades (especies) adaptados a las nuevas condiciones climatológicas e instrumentar programas de cultivos adaptados a las condiciones locales (secano, regadío)" type="radio" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-bottom border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-bottom border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Gestión integrada de plagas o Manejo Ecológico de Plagas (MEP)</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Gestión integrada de plagas o Manejo Ecológico de Plagas (MEP)" type="radio" name="options1" id="option1"></div>
            </div>
            <!-- 1.2 -->


            <!-- 2.1 -->
           
            <div class="row container">
            <div  class="col-md-3 border-left border-bottom border-dark" style="background: #E2E3E5;" >2.1 Desarrollo de nuevos productos y servicios por parte de pequeños productores y pequeñas empresas</div>
            <div  class="col-md-1 border-left border-bottom border-dark" style="background: #E2E3E5;"><input value="2.1 Desarrollo de nuevos productos y servicios por parte de pequeños productores y pequeñas empresas" type="radio" name="options1" id="options1"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >PROYECTO TERRITORIAL: Desarrollo Línea Gourmet Productos Locales (CARDENAL CARO)</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="PROYECTO TERRITORIAL: Desarrollo Línea Gourmet Productos Locales (CARDENAL CARO)" type="radio" name="options1" id="option1"></div>
            </div>
           
            <!-- 2.1 -->


          <!-- 2.2 -->
          <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >PROYECTO TERRITORIAL: Consorcio Regional para la Gestión Tecnológica y Social (CACHAPOAL)</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="PROYECTO TERRITORIAL: Consorcio Regional para la Gestión Tecnológica y Social (CACHAPOAL)" type="radio" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Proyectos Innovadores para responder a los desafíos de las grandes y medianas empresas y los servicios públicos de la Región de O’Higgins.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Proyectos Innovadores para responder a los desafíos de las grandes y medianas empresas y los servicios públicos de la Región de O’Higgins." type="radio" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" >2.2 Incorporación de tecnologías, emprendimientos y servicios 4.0.</div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"><input value="Incorporación de tecnologías, emprendimientos y servicios 4.0" type="radio" name="options1" id="options1"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >La incorporación de tecnologías 4.0 por parte de pequeños productores y pequeñas empresas, para la adquisición de ventajas competitivas.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="La incorporación de tecnologías 4.0 por parte de pequeños productores y pequeñas empresas, para la adquisición de ventajas competitivas." type="radio" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Emprendimiento innovador, que aproveche las oportunidades que se abren en la extensión de las tecnologías 4.0.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Emprendimiento innovador, que aproveche las oportunidades que se abren en la extensión de las tecnologías 4.0" type="radio" name="options1" id="options1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-bottom border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-bottom border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Servicios avanzados de apoyo a los sectores económicos de la región, minería, agroindustria, construcción y ERNC, que requieren este tipo de tecnologías y que demandan servicios avanzados</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Servicios avanzados de apoyo a los sectores económicos de la región, minería, agroindustria, construcción y ERNC, que requieren este tipo de tecnologías y que demandan servicios avanzados" type="radio" name="options1" id="options1"></div>
            </div>
           
          <!-- 2.2 -->



          <!-- 2.3 -->

          <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >PROYECTO TERRITORIAL: Capital Humano y puesta en valor de productos regionales (COLCHAGUA)</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="PROYECTO TERRITORIAL: Capital Humano y puesta en valor de productos regionales (COLCHAGUA)" type="radio" name="options1" id="options1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left  border-dark" style="background: #E2E3E5;" >2.3 Puesta en valor en el mercado de los productos, servicios regionales, patrimonio arquitectónico y físico o natural.</div>
            <div  class="col-md-1 border-left  border-dark" style="background: #E2E3E5;"><input type="radio" value="Puesta en valor en el mercado de los productos, servicios regionales, patrimonio arquitectónico y físico o natural." name="options1" id="options1"></div>
            <div  class="col-md-4 border  border-dark" style="background: #E2E3E5;" >Sello/Marca de Origen y Sustentabilidad Regional.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input type="radio" value="Sello/Marca de Origen y Sustentabilidad Regional." name="options1" id="options1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-bottom border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left  border-bottom border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Rutas Región de O’Higgins.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input type="radio" value="Rutas Región de O’Higgins." name="options1" id="options1"></div>
            </div>

          <!-- 2.3 -->


          <!-- 3.1 -->

            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Consorcio Regional para Información, formación y extensionismo para el cambio climático</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input type="radio" value="Consorcio Regional para Información, formación y extensionismo para el cambio climático" name="options1" id="options1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" >3.1 Información, Formación y Extensionismo</div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"><input type="radio" value="Información, Formación y Extensionismo" name="options1" id="options1"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >PROYECTO TERRITORIAL: Extensión de la oferta de Formación Técnica a la provincia de Cardenal Caro.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="PROYECTO TERRITORIAL: Extensión de la oferta de Formación Técnica a la provincia de Cardenal Caro." type="radio" name="options1" id="options1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >Información para: </div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Información para:" type="radio" name="options1" id="options1"></div>
            </div><div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" > Las tecnologías 4.0 </div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Las tecnologías 4.0" type="radio" name="options1" id="option1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" > Cambio climático y sustentabilidad ambiental.</div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="Cambio climático y sustentabilidad ambiental." type="radio" name="options1" id="options1"></div>
            </div>
            <div class="row container">
            <div  class="col-md-3 border-left border-bottom border-dark" style="background: #E2E3E5;" ></div>
            <div  class="col-md-1 border-left border-bottom border-dark" style="background: #E2E3E5;"></div>
            <div  class="col-md-4 border border-dark" style="background: #E2E3E5;" >La promoción y la comercialización. </div>
            <div align="center" class="pt-2 col-md-1 border border-dark" style="background: #E2E3E5;"><input value="La promoción y la comercialización." type="radio" name="options1" id="options1"></div>
            </div>

<?php 



?>
