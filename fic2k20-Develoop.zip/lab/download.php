<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!--<a href="ruta de archivo" download="nombre de archivo con extencion de tipo de archivo">-->
<a href="../src/anexos/anexo_1.docx" download="anexo_1.docx">Descargar Anexo 1</a>
<a href="../src/anexos/anexo_2.docx" download="anexo_2.docx">Descargar Anexo 1</a>
<a href="../src/anexos/anexo_3.docx" download="anexo_3.docx">Descargar Anexo 1</a>
<a href="../src/anexos/anexo_4.docx" download="anexo_4.docx">Descargar Anexo 1</a>
<a href="../src/anexos/anexo_5.docx" download="anexo_5.docx">Descargar Anexo 1</a>
<a href="../src/anexos/anexo_6.docx" download="anexo_6.docx">Descargar Anexo 1</a>
<a href="../src/anexos/anexo_7.docx" download="anexo_7.docx">Descargar Anexo 1</a>
<a href="../src/anexos/anexo_objetivos_especificos.docx" download="anexo_objetivos_especificos.docx">Descargar Anexo 1</a>
<a href="../src/anexos/formato_carta_gantt_2020.xls" download="formato_carta_gantt_2020.xls">Descargar Anexo 1</a>
<a href="../src/anexos/indicadores_evaluacion_ex-ante.xlsx" download="indicadores_evaluacion_ex-ante.xlsx">Descargar Anexo 1</a>
<a href="../src/anexos/integrantes.xlsx" download="integrantes.xlsx">Descargar Anexo 1</a>
<a href="../src/anexos/presupuesto.xlsx" download="presupuesto.xlsx">La descarga y subida de los "Objetivos Específicos" se ubica aquí</a>
<a href="../src/anexos/resultados_esperados.xlsx" download="resultados_esperados.xlsx">Descargar Anexo 1</a>
</body>
</html>