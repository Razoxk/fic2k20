<?php
    include '../php/db.php';

    $idProyecto = $_GET['id'];

    $sqlProyecto = "SELECT * FROM proyecto WHERE id = $idProyecto ";
    foreach ($conn->query($sqlProyecto) as $row){
        $id_proyecto = $row['id'];
        $nombreProyecto = $row['nombre'];
        $nombreEntidad = $row['nombre_entidad'];
        $nombreEstado = $row['estado'];
    }

    $sqlAnexos = "SELECT * FROM anexos WHERE id_proyecto = $idProyecto ";
    foreach ($conn->query($sqlAnexos) as $row){
        $anexo2 = $row['anexo_2'];
        $anexo3 = $row['anexo_3'];
        $graficoImagen = $row['grafico_imagen'];
        $objetivosEspecificos = $row['objetivos_especificos'];
        $anexo6 = $row['anexo_6'];
        $presupuestoDetallado = $row['presupuesto_detallado'];
        $resultadosEsperados = $row['resultados_esperados'];
        $indicadorEvaluacion = $row['indicador_evaluacion'];
        $cartaGantt = $row['carta_gantt'];
        $funcionIntegrantes = $row['funcion_integrantes'];
        $copiaRolTributario = $row['copia_rol_tributario'];
        $copiaCedulaIdentidad = $row['copia_cedula_identidad'];
        $copiaInstrumento = $row['copia_instrumento'];
        $cartaAutoridad = $row['carta_autoridad'];
        $antecedentesRelevantes = $row['antecedentes_relevantes'];
        $copiaCertificadoVigencia = $row['copia_certificado_vigencia'];
        
    }
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <title>Información del proyecto</title>
</head>
<body>
<div class="container">

    <div class="jumbotron">
        <h3 class="display-5"> Información del proyecto </h2>
        <hr class="my-4">
        <p>Nombre: <?php echo $nombreProyecto; ?></p>
        
        <p>Entidad: <?php echo $nombreEntidad; ?></p>
        
        <p>Estado: <?php echo $nombreEstado; ?></p>
        
        <br>
        <h3 class="display-5"> Archivos adjuntos </h2>
        <hr class="my-4">
        <table>
            <tr>
                <td>Objetivos Específicos</td>
                <td class="pl-4"><a href="../php/<?php echo $objetivosEspecificos; ?>"> Descargar</a></td>
            </tr>
            <tr>
                <td>Resultados Esperados e Indicadores de Resultados</td>
                <td class="pl-4"><a href="../php/<?php echo $resultadosEsperados; ?>"> Descargar</a></td>
            </tr>
            
            <tr>
                <td>Indicadores de evaluación Ex-ante</td>
                <td class="pl-4"><a href="../php/<?php echo $indicadorEvaluacion; ?>"> Descargar</a></td>
            </tr>
            <tr>
                <td>Carta Gantt</td>
                <td class="pl-4"><a href="../php/<?php echo $cartaGantt; ?>"> Descargar</a></td>
            </tr>
            <tr>
                <td>Carta de Declaración de Responsabilidad</td>
                <td class="pl-4"><a href="../php/<?php echo $anexo2; ?>"> Descargar</a></td>
            </tr>
            <tr>
                <td>Formatos de Cartas</td>
                <td class="pl-4"><a href="../php/<?php echo $anexo3; ?>"> Descargar</a></td>
            </tr>
            
            <tr>
                <td>Gráfico e Imágen</td>
                <td class="pl-4"><a href="../php/<?php echo $graficoImagen; ?>"> Descargar</a></td>
            </tr>
            
            <tr>
                <td>Formato de Carta Compromiso Costos de Operación Post Proyecto</td>
                <td class="pl-4"><a href="../php/<?php echo $anexo6; ?>"> Descargar</a></td>
            </tr>
            
            <tr>
                <td>Presupuesto detallado del proyecto</td>
                <td class="pl-4"><a href="../php/<?php echo $presupuestoDetallado; ?>"> Descargar</a></td>
            </tr>
            
            <tr>
                <td>Función de cada integrante del proyecto y horas dedicadas</td>
                <td class="pl-4"><a href="../php/<?php echo $funcionIntegrantes; ?>"> Descargar</a></td>
            </tr>
            <tr>
                <td>Copia simple del Rol Único Tributario de la Entidad postulante</td>
                <td class="pl-4"><a href="../php/<?php echo $copiaRolTributario; ?>"> Descargar</a></td>
            </tr>
            <tr>
                <td>Copia simple de la Cédula de Identidad del representante legal o mandatario</td>
                <td class="pl-4"><a href="../php/<?php echo $copiaCedulaIdentidad; ?>"> Descargar</a></td>
            </tr>
            <tr>
                <td> Copia simple del instrumento que nombra al representante legal o mandatario y del que lo faculta para firmar</td>
                <td class="pl-4"><a href="../php/<?php echo $copiaInstrumento; ?>"> Descargar</a></td>
            </tr>
            <?php 

                if (!empty($cartaAutoridad)) {

                    echo "
                    <tr>
                        <td>Opcional - Carta de la autoridad sectorial o territorial</td>
                        <td class='pl-4'><a href='../php/$cartaAutoridad'> Descargar</a></td>
                    </tr>";
                }
                
                
                if (!empty($cartaAutoridad)) {

                    echo "
                    <tr>
                        <td>Opcional - Incorporar adicionalmente antecedentes relevantes de la iniciativa</td>
                        <td class='pl-4'><a href='../php/$antecedentesRelevantes'> Descargar</a></td>
                    </tr>";
                }
            ?>
            
        </table>
        <br>

        <?php 

        if (!empty($copiaCertificadoVigencia)) {
            
        echo "<h3 class='display-5'> Archivos adjuntos privados </h2>
        <hr class='my-4'>
        <table>
            <tr>
                <td>Copia certificado vigencia </td>
                <td class='pl-4'><a href='../php/$copiaCertificadoVigencia'> Descargar</a></td>
            </tr>
        </table>";
        }
        ?>

        <p></p>
    </div>

</div>
    
</body>
</html>