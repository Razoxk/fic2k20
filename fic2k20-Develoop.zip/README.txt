------------------------------------------------------
                        Notas
------------------------------------------------------

* El archivo db contiene una conexion ya realizada, por lo tanto solo se debe incluir
y realizar la consulta mediante la variable de conexion $conn




