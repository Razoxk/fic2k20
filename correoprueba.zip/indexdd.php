<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INICIO</title>
</head>
<body>
    
    <a href="publico.php">PUBLICO</a>
    <a href="privado.php">PRIVADO</a>

</body>
</html>