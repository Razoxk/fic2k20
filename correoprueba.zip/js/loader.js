window.onload = function(){
    $('#onload').fadeOut();
    $('body').removeClass('hidden');
}